import os
import random
from threading import Lock

import numpy as np
import pandas as pd
from sklearn import svm
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, precision_score, recall_score
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier


FEATURES = [
    "station_id", "region", "latitude", "longitude", "elevation_m",
    "temperature_c", "humidity_pct", "pressure_hpa", "rainfall_mm",
    "wind_speed_kmh", "co2_ppm", "solar_radiation_wm2",
    "soil_moisture_pct", "sea_surface_temp_c"
]
TARGET = "is_extreme_event"

REGION_STATIONS = {
    1: [
        ("AMR_NY_01", "New York", "Americas", 40.71, -74.01, 10, 16, 66, 4.0, 18, 45, 17),
        ("AMR_MEX_02", "Mexico City", "Americas", 19.43, -99.13, 2240, 18, 55, 3.2, 14, 38, 27),
        ("AMR_SAO_03", "Sao Paulo", "Americas", -23.55, -46.63, 760, 21, 74, 5.5, 16, 55, 24),
        ("AMR_LIM_04", "Lima", "Americas", -12.05, -77.04, 154, 19, 78, 0.8, 13, 32, 18),
        ("AMR_VAN_05", "Vancouver", "Americas", 49.28, -123.12, 70, 11, 78, 5.0, 17, 58, 11),
        ("AMR_BUE_06", "Buenos Aires", "Americas", -34.60, -58.38, 25, 18, 72, 4.2, 20, 50, 18),
    ],
    2: [
        ("EMA_LON_01", "London", "Europe-Africa", 51.51, -0.13, 24, 12, 75, 3.5, 18, 60, 12),
        ("EMA_OSL_02", "Oslo", "Europe-Africa", 59.91, 10.75, 23, 7, 72, 2.8, 16, 55, 8),
        ("EMA_CAI_03", "Cairo", "Europe-Africa", 30.04, 31.24, 23, 25, 38, 0.4, 15, 18, 24),
        ("EMA_NBO_04", "Nairobi", "Europe-Africa", -1.29, 36.82, 1795, 20, 62, 3.8, 14, 48, 26),
        ("EMA_CPT_05", "Cape Town", "Europe-Africa", -33.92, 18.42, 25, 17, 67, 2.7, 23, 42, 16),
        ("EMA_PAR_06", "Paris", "Europe-Africa", 48.86, 2.35, 35, 13, 70, 3.1, 17, 58, 13),
    ],
    3: [
        ("APC_HYD_01", "Hyderabad", "Asia-Pacific", 17.39, 78.49, 542, 27, 55, 3.6, 15, 34, 28),
        ("APC_TYO_02", "Tokyo", "Asia-Pacific", 35.68, 139.69, 40, 17, 68, 5.2, 19, 52, 19),
        ("APC_SIN_03", "Singapore", "Asia-Pacific", 1.35, 103.82, 15, 28, 82, 8.0, 13, 68, 29),
        ("APC_SYD_04", "Sydney", "Asia-Pacific", -33.87, 151.21, 58, 20, 64, 4.3, 21, 45, 21),
        ("APC_BKK_05", "Bangkok", "Asia-Pacific", 13.76, 100.50, 2, 29, 74, 6.5, 12, 55, 29),
        ("APC_SEO_06", "Seoul", "Asia-Pacific", 37.57, 126.98, 38, 13, 63, 4.1, 17, 46, 16),
    ],
}


class ClimateMLEngine:
    """Climate-event modeling engine for geographically distributed observations."""

    def __init__(self, base_dir):
        self.base_dir = base_dir
        self.dataset_path = os.path.join(base_dir, "Dataset", "global_climate_dataset.csv")
        self.scaler = None
        self.encoders = {}
        self.model = None
        self.model_name = None
        self.metrics = []
        self.lock = Lock()
        self.prepared = False

    def dataset_overview(self):
        df = pd.read_csv(self.dataset_path)
        regions = df["region"].value_counts().to_dict()
        events = df["event_type"].value_counts().to_dict()
        return {
            "rows": int(len(df)),
            "features": len(FEATURES),
            "normal": int((df[TARGET] == 0).sum()),
            "extreme": int((df[TARGET] == 1).sum()),
            "stations": int(df["station_id"].nunique()),
            "regions": regions,
            "events": events,
            "columns": list(df.columns),
        }

    def _prepare_dataset(self):
        df = pd.read_csv(self.dataset_path, usecols=FEATURES + [TARGET]).copy()
        self.encoders = {}
        for col in FEATURES:
            if df[col].dtype == object:
                encoder = LabelEncoder()
                df[col] = encoder.fit_transform(df[col].astype(str))
                self.encoders[col] = encoder
        X = df[FEATURES].values.astype(float)
        y = df[TARGET].values.astype(int)
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.25, random_state=42, stratify=y
        )
        self.scaler = StandardScaler()
        X_train = self.scaler.fit_transform(X_train)
        X_test = self.scaler.transform(X_test)
        self.prepared = True
        return X_train, X_test, y_train, y_test

    @staticmethod
    def _metric_row(name, y_true, pred):
        return {
            "algorithm": name,
            "accuracy": round(accuracy_score(y_true, pred) * 100, 2),
            "precision": round(precision_score(y_true, pred, average="macro", zero_division=0) * 100, 2),
            "recall": round(recall_score(y_true, pred, average="macro", zero_division=0) * 100, 2),
            "fscore": round(f1_score(y_true, pred, average="macro", zero_division=0) * 100, 2),
            "confusion_matrix": confusion_matrix(y_true, pred, labels=[0, 1]).tolist(),
        }

    def train_all(self):
        with self.lock:
            X_train, X_test, y_train, y_test = self._prepare_dataset()
            algorithms = [
                ("Naive Bayes", GaussianNB()),
                ("Support Vector Machine", svm.SVC(C=3.0, kernel="rbf", gamma="scale")),
                ("Random Forest", RandomForestClassifier(n_estimators=180, random_state=42, max_depth=None)),
                ("Decision Tree", DecisionTreeClassifier(random_state=42, max_depth=10)),
                ("Logistic Regression", LogisticRegression(max_iter=1200, random_state=42)),
            ]

            metrics = []
            trained = []
            for name, classifier in algorithms:
                classifier.fit(X_train, y_train)
                pred = classifier.predict(X_test)
                metrics.append(self._metric_row(name, y_test, pred))
                trained.append((name, classifier))

            best_index = max(range(len(metrics)), key=lambda idx: metrics[idx]["fscore"])
            self.model_name, self.model = trained[best_index]
            self.metrics = metrics
            return {
                "metrics": metrics,
                "best_model": self.model_name,
                "best_accuracy": metrics[best_index]["accuracy"],
            }

    def ensure_model(self):
        if self.model is None:
            self.train_all()

    def _safe_transform(self, col, value):
        encoder = self.encoders.get(col)
        if encoder is None:
            return value
        text = str(value)
        classes = list(encoder.classes_)
        if text not in classes:
            text = classes[0]
        return int(encoder.transform([text])[0])

    def predict(self, observation):
        self.ensure_model()
        row = []
        for col in FEATURES:
            value = observation[col]
            if col in self.encoders:
                value = self._safe_transform(col, value)
            row.append(value)
        X = self.scaler.transform(np.asarray([row], dtype=float))
        return int(self.model.predict(X)[0])

    @staticmethod
    def climate_event_name(observation, prediction):
        if int(prediction) == 0:
            return "Normal Climate"
        if observation["rainfall_mm"] >= 70:
            return "Heavy Rainfall"
        if observation["wind_speed_kmh"] >= 65:
            return "Wind Storm"
        if observation["soil_moisture_pct"] <= 22 and observation["temperature_c"] >= 30:
            return "Drought / Heat Stress"
        if observation["temperature_c"] >= 35:
            return "Heatwave"
        if observation["pressure_hpa"] <= 985:
            return "Low Pressure Event"
        return "Extreme Climate Event"

    def generate_observation(self, visual_node_number, cloud_id):
        cloud_id = int(cloud_id)
        stations = REGION_STATIONS.get(cloud_id, REGION_STATIONS[1])
        station = stations[(int(visual_node_number) - 1) % len(stations)]
        sid, city, region, lat, lon, elevation, base_temp, base_hum, base_rain, base_wind, base_soil, base_sst = station

        temperature = base_temp + random.gauss(0, 4.0)
        humidity = max(10, min(99, base_hum + random.gauss(0, 10)))
        pressure = max(920, min(1045, 1013 - (elevation / 8500.0) * 75 + random.gauss(0, 7)))
        rainfall = max(0, random.gauss(base_rain, max(1.5, base_rain)))
        wind = max(1, random.gauss(base_wind, 7))
        co2 = max(390, min(480, random.gauss(423, 12)))
        solar = max(30, min(1150, random.gauss(590, 180)))
        soil = max(4, min(96, base_soil + rainfall * 0.9 + random.gauss(0, 10)))
        sst = max(-2, min(36, base_sst + random.gauss(0, 2.2)))

        if random.random() < 0.38:
            kind = random.choice(["heat", "rain", "storm", "drought"])
            if kind == "heat":
                temperature += random.uniform(10, 16); humidity -= random.uniform(10, 22); rainfall *= 0.1; soil -= random.uniform(12, 25); solar += random.uniform(100, 250)
            elif kind == "rain":
                rainfall = random.uniform(80, 200); humidity = random.uniform(88, 99); pressure -= random.uniform(15, 30); wind += random.uniform(12, 35); soil += random.uniform(18, 30)
            elif kind == "storm":
                wind = random.uniform(75, 140); pressure -= random.uniform(24, 45); rainfall += random.uniform(15, 75); humidity += random.uniform(6, 15)
            else:
                temperature += random.uniform(8, 14); humidity = random.uniform(16, 32); rainfall = random.uniform(0, 0.7); soil = random.uniform(5, 18); solar += random.uniform(120, 250)

        return {
            "station_id": sid,
            "station_name": city,
            "region": region,
            "latitude": round(lat, 4),
            "longitude": round(lon, 4),
            "elevation_m": int(elevation),
            "temperature_c": round(max(-35, min(55, temperature)), 2),
            "humidity_pct": round(max(5, min(100, humidity)), 2),
            "pressure_hpa": round(max(900, min(1050, pressure)), 2),
            "rainfall_mm": round(max(0, min(250, rainfall)), 2),
            "wind_speed_kmh": round(max(0, min(170, wind)), 2),
            "co2_ppm": round(max(370, min(500, co2)), 2),
            "solar_radiation_wm2": round(max(0, min(1200, solar)), 2),
            "soil_moisture_pct": round(max(2, min(100, soil)), 2),
            "sea_surface_temp_c": round(max(-2, min(36, sst)), 2),
        }
