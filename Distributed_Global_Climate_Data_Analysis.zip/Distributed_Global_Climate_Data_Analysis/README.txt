DISTRIBUTED SYSTEM FOR GLOBAL CLIMATE DATA ANALYSIS
===================================================

Goal
----
Enable collaborative analysis of climate datasets across geographically distributed nodes.

Core Technologies
-----------------
- Distributed Computing
- Cloud Analytics
- Climate Modeling / Machine Learning
- Python + Flask
- TCP Socket Servers
- SQLite
- Pandas / NumPy / scikit-learn
- HTML / CSS / JavaScript / SVG

Application Workflow
--------------------
1. Sign Up -> Login.
2. Start the three Regional Climate Cloud servers.
   Cloud 1: Americas Climate Cloud       -> Port 5555
   Cloud 2: Europe-Africa Climate Cloud  -> Port 6666
   Cloud 3: Asia-Pacific Climate Cloud   -> Port 7777
3. Generate geographically distributed climate nodes.
4. Run Climate Machine Learning to compare five classifiers.
5. Run Distributed Global Climate Analysis Simulation.
6. Open Climate Event Analytics & History to inspect combined results.

Dataset
-------
Dataset/global_climate_dataset.csv

The project includes 2,400 synthetic educational observations from 18 representative
climate stations across three geographic regions. Climate variables include temperature,
humidity, atmospheric pressure, rainfall, wind speed, CO2, solar radiation, soil moisture,
sea-surface temperature, geographic coordinates and elevation.

Target:
- 0 = Normal Climate
- 1 = Extreme Climate Event

Extreme-event patterns include Heatwave, Heavy Rainfall, Wind Storm and Drought / Heat Stress.
The dataset is synthetic and intended for classroom simulation, not operational forecasting.

Run
---
1. Open Command Prompt in this project folder.
2. Install dependencies if needed:
   pip install -r requirements.txt
3. Run:
   python app.py
   OR double-click run_web.bat
4. Open:
   http://127.0.0.1:8000

Optional Dataset Regeneration
-----------------------------
python generate_climate_dataset.py

This recreates Dataset/global_climate_dataset.csv using a fixed random seed.
