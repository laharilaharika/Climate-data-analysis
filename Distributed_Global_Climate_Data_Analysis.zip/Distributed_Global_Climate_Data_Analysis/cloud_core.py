import pickle
import socket
import threading
import time
from datetime import datetime


REGION_NAMES = {1: "Americas Climate Cloud", 2: "Europe-Africa Climate Cloud", 3: "Asia-Pacific Climate Cloud"}


class DistributedClimateServer(threading.Thread):
    """Small TCP analytics node used by the distributed climate simulation."""

    def __init__(self, cloud_id, port, log_callback=None):
        super().__init__(daemon=True)
        self.cloud_id = int(cloud_id)
        self.port = int(port)
        self.log_callback = log_callback
        self._running = threading.Event()
        self._running.set()
        self.server_socket = None

    def log(self, message):
        if self.log_callback:
            self.log_callback(self.cloud_id, self.port, message)

    def run(self):
        try:
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind(("127.0.0.1", self.port))
            self.server_socket.listen(8)
            self.server_socket.settimeout(1.0)
            self.log("ONLINE - waiting for geographically distributed climate observations")

            while self._running.is_set():
                try:
                    conn, addr = self.server_socket.accept()
                except socket.timeout:
                    continue
                except OSError:
                    break
                threading.Thread(target=self.handle_client, args=(conn, addr), daemon=True).start()
        except OSError as exc:
            self.log("ERROR - %s" % exc)
        finally:
            try:
                if self.server_socket:
                    self.server_socket.close()
            except OSError:
                pass

    def handle_client(self, conn, addr):
        with conn:
            try:
                observation = pickle.loads(conn.recv(65536))
                self.log(
                    "Processed %s (%s) | temp=%s C | rain=%s mm | wind=%s km/h"
                    % (
                        observation.get("station_id", "unknown"),
                        observation.get("station_name", "-"),
                        observation.get("temperature_c", "-"),
                        observation.get("rainfall_mm", "-"),
                        observation.get("wind_speed_kmh", "-"),
                    )
                )
                response = {
                    "ok": True,
                    "cloud_id": self.cloud_id,
                    "region_name": REGION_NAMES[self.cloud_id],
                    "port": self.port,
                    "processed_at": datetime.now().isoformat(timespec="seconds"),
                    "forwarded_to_global_monitor": True,
                }
                conn.sendall(pickle.dumps(response))
            except Exception as exc:
                self.log("OBSERVATION ERROR - %s" % exc)
                try:
                    conn.sendall(pickle.dumps({"ok": False, "error": str(exc)}))
                except Exception:
                    pass

    def stop(self):
        self._running.clear()
        try:
            if self.server_socket:
                self.server_socket.close()
        except OSError:
            pass


class ClimateCloudManager:
    PORTS = {1: 5555, 2: 6666, 3: 7777}
    REGIONS = REGION_NAMES

    def __init__(self):
        self.servers = {}
        self.logs = []
        self.lock = threading.Lock()

    def add_log(self, cloud_id, port, message):
        item = {
            "time": datetime.now().strftime("%H:%M:%S"),
            "cloud_id": cloud_id,
            "port": port,
            "region_name": self.REGIONS[cloud_id],
            "message": message,
        }
        with self.lock:
            self.logs.append(item)
            self.logs = self.logs[-150:]

    def start_all(self):
        started, already = [], []
        for cloud_id, port in self.PORTS.items():
            server = self.servers.get(cloud_id)
            if server and server.is_alive():
                already.append(port)
                continue
            server = DistributedClimateServer(cloud_id, port, self.add_log)
            self.servers[cloud_id] = server
            server.start()
            started.append(port)
        time.sleep(0.2)
        return {"started": started, "already_running": already, "status": self.status()}

    def status(self):
        output = []
        for cloud_id, port in self.PORTS.items():
            server = self.servers.get(cloud_id)
            output.append({
                "cloud_id": cloud_id,
                "port": port,
                "region_name": self.REGIONS[cloud_id],
                "online": bool(server and server.is_alive()),
            })
        return output

    def recent_logs(self):
        with self.lock:
            return list(self.logs[-40:])

    def send_observation(self, cloud_id, observation):
        cloud_id = int(cloud_id)
        if cloud_id not in self.PORTS:
            raise ValueError("Invalid regional climate cloud")
        port = self.PORTS[cloud_id]
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client:
            client.settimeout(3.0)
            client.connect(("127.0.0.1", port))
            client.sendall(pickle.dumps(observation))
            data = client.recv(65536)
        return pickle.loads(data)
