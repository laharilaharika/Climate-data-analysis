const startBtn=document.getElementById('startServers');
const message=document.getElementById('serverMessage');
const logBox=document.getElementById('serverLogs');

function renderStatus(status){
  status.forEach(s=>{
    const card=document.querySelector(`[data-cloud="${s.cloud_id}"]`); if(!card)return;
    card.classList.toggle('online',s.online);
    const dot=card.querySelector('.status-dot'); dot.classList.toggle('online',s.online);
    card.querySelector('.server-state').textContent=s.online?'ONLINE':'OFFLINE';
  });
}
function renderLogs(logs){
  if(!logs||!logs.length){logBox.innerHTML='<div class="terminal-line muted">No regional climate observations processed yet.</div>';return;}
  logBox.innerHTML=logs.slice().reverse().map(l=>`<div class="terminal-line"><span class="time">[${l.time}]</span> <span class="cloud">${l.region_name} : ${l.port}</span> ${l.message}</div>`).join('');
}
async function refresh(){
  try{const r=await fetch('/api/server-status');const d=await r.json();renderStatus(d.status);renderLogs(d.logs);}catch(e){}
}
startBtn.addEventListener('click',async()=>{
  startBtn.disabled=true;startBtn.textContent='Starting Climate Clouds...';
  try{
    const r=await fetch('/api/start-servers',{method:'POST'});const d=await r.json();renderStatus(d.status);
    message.className='inline-message success';
    message.textContent='Regional climate analytics layer is online on ports 5555, 6666 and 7777.';
    await refresh();
  }catch(e){message.className='inline-message error';message.textContent='Unable to start climate cloud servers: '+e.message;}
  finally{startBtn.disabled=false;startBtn.textContent='Start All 3 Climate Clouds';}
});
refresh();setInterval(refresh,3500);
