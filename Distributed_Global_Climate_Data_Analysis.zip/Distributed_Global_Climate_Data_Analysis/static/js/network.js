const svg=document.getElementById('networkSvg');
const countInput=document.getElementById('userCount');
const info=document.getElementById('topologyInfo');
const NS='http://www.w3.org/2000/svg';
const clouds=[
  {id:1,x:205,y:330,port:5555,region:'Americas'},
  {id:2,x:500,y:345,port:6666,region:'Europe-Africa'},
  {id:3,x:795,y:330,port:7777,region:'Asia-Pacific'}
];
const monitor={x:500,y:70,label:'GLOBAL MONITOR'};
const bounds=[
  {region:'Americas',x1:55,x2:350,y1:145,y2:535},
  {region:'Europe-Africa',x1:365,x2:635,y1:150,y2:535},
  {region:'Asia-Pacific',x1:650,x2:945,y1:145,y2:535}
];
function el(name,attrs={}){const n=document.createElementNS(NS,name);Object.entries(attrs).forEach(([k,v])=>n.setAttribute(k,v));return n;}
function text(x,y,value,cls='node-label'){const t=el('text',{x,y,class:cls});t.textContent=value;svg.appendChild(t);}
function background(){
  svg.appendChild(el('path',{d:'M55 160 C120 95 275 100 340 175 C365 210 330 255 285 260 C240 268 210 245 175 265 C120 295 60 250 45 205 C38 185 43 172 55 160Z',class:'continent-shape'}));
  svg.appendChild(el('path',{d:'M385 155 C430 105 565 100 625 165 C654 195 632 235 595 245 C555 257 565 300 535 326 C500 355 452 325 447 285 C443 248 405 235 380 205 C365 186 370 170 385 155Z',class:'continent-shape'}));
  svg.appendChild(el('path',{d:'M665 160 C725 100 890 108 950 180 C975 210 948 245 905 250 C860 255 845 286 803 296 C755 307 700 278 678 238 C660 205 648 180 665 160Z',class:'continent-shape'}));
  text(190,125,'AMERICAS','region-label');text(500,125,'EUROPE / AFRICA','region-label');text(800,125,'ASIA / PACIFIC','region-label');
  for(let x=0;x<=1000;x+=100)svg.appendChild(el('line',{x1:x,y1:0,x2:x,y2:600,class:'grid-line'}));
  for(let y=0;y<=600;y+=100)svg.appendChild(el('line',{x1:0,y1:y,x2:1000,y2:y,class:'grid-line'}));
}
function tooNear(users,x,y){return users.some(u=>Math.hypot(u.x-x,u.y-y)<48)||clouds.some(c=>Math.hypot(c.x-x,c.y-y)<78)||Math.hypot(monitor.x-x,monitor.y-y)<85;}
function makeUsers(count){
  const users=[];let attempts=0;
  while(users.length<count&&attempts<7000){attempts++;const ri=users.length%3,b=bounds[ri];const x=b.x1+Math.random()*(b.x2-b.x1),y=b.y1+Math.random()*(b.y2-b.y1);if(!tooNear(users,x,y))users.push({id:users.length+1,x:Math.round(x),y:Math.round(y),region:b.region});}
  return users;
}
function draw(topology){
  svg.innerHTML='';background();
  svg.appendChild(el('circle',{cx:monitor.x,cy:monitor.y,r:36,class:'monitor-node'}));text(monitor.x,monitor.y+4,'GLOBAL');text(monitor.x,monitor.y+53,'Climate Monitor','sub-label');
  clouds.forEach(c=>{svg.appendChild(el('circle',{cx:c.x,cy:c.y,r:34,class:'cloud-node'}));text(c.x,c.y+4,'C'+c.id);text(c.x,c.y+52,c.region,'sub-label');text(c.x,c.y+66,'Port '+c.port,'sub-label');});
  topology.users.forEach(u=>{svg.appendChild(el('circle',{cx:u.x,cy:u.y,r:18,class:'climate-node'}));text(u.x,u.y+4,'N'+u.id,'tiny-label');});
  info.textContent=`${topology.users.length} climate nodes · 3 regional clouds · 1 global monitor`;
}
function generate(){const count=Math.max(6,Math.min(36,parseInt(countInput.value||18)));countInput.value=count;const topology={users:makeUsers(count),clouds,monitor,created:Date.now()};localStorage.setItem('globalClimateTopology',JSON.stringify(topology));draw(topology);}
document.getElementById('generateNetwork').addEventListener('click',generate);
const saved=localStorage.getItem('globalClimateTopology');if(saved){try{const t=JSON.parse(saved);countInput.value=t.users.length;draw(t);}catch(e){generate();}}else generate();
