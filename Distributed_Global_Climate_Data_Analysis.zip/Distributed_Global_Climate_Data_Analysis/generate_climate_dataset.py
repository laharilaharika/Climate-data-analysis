import csv
import math
import os
import random
from datetime import datetime, timedelta

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE_DIR, "Dataset", "global_climate_dataset.csv")
random.seed(42)

STATIONS = [
    # station_id, city, region, lat, lon, elevation, base_temp, humidity, rainfall, wind, soil, sst
    ("AMR_NY_01", "New York", "Americas", 40.71, -74.01, 10, 16, 66, 4.0, 18, 45, 17),
    ("AMR_MEX_02", "Mexico City", "Americas", 19.43, -99.13, 2240, 18, 55, 3.2, 14, 38, 27),
    ("AMR_SAO_03", "Sao Paulo", "Americas", -23.55, -46.63, 760, 21, 74, 5.5, 16, 55, 24),
    ("AMR_LIM_04", "Lima", "Americas", -12.05, -77.04, 154, 19, 78, 0.8, 13, 32, 18),
    ("AMR_VAN_05", "Vancouver", "Americas", 49.28, -123.12, 70, 11, 78, 5.0, 17, 58, 11),
    ("AMR_BUE_06", "Buenos Aires", "Americas", -34.60, -58.38, 25, 18, 72, 4.2, 20, 50, 18),
    ("EMA_LON_01", "London", "Europe-Africa", 51.51, -0.13, 24, 12, 75, 3.5, 18, 60, 12),
    ("EMA_OSL_02", "Oslo", "Europe-Africa", 59.91, 10.75, 23, 7, 72, 2.8, 16, 55, 8),
    ("EMA_CAI_03", "Cairo", "Europe-Africa", 30.04, 31.24, 23, 25, 38, 0.4, 15, 18, 24),
    ("EMA_NBO_04", "Nairobi", "Europe-Africa", -1.29, 36.82, 1795, 20, 62, 3.8, 14, 48, 26),
    ("EMA_CPT_05", "Cape Town", "Europe-Africa", -33.92, 18.42, 25, 17, 67, 2.7, 23, 42, 16),
    ("EMA_PAR_06", "Paris", "Europe-Africa", 48.86, 2.35, 35, 13, 70, 3.1, 17, 58, 13),
    ("APC_HYD_01", "Hyderabad", "Asia-Pacific", 17.39, 78.49, 542, 27, 55, 3.6, 15, 34, 28),
    ("APC_TYO_02", "Tokyo", "Asia-Pacific", 35.68, 139.69, 40, 17, 68, 5.2, 19, 52, 19),
    ("APC_SIN_03", "Singapore", "Asia-Pacific", 1.35, 103.82, 15, 28, 82, 8.0, 13, 68, 29),
    ("APC_SYD_04", "Sydney", "Asia-Pacific", -33.87, 151.21, 58, 20, 64, 4.3, 21, 45, 21),
    ("APC_BKK_05", "Bangkok", "Asia-Pacific", 13.76, 100.50, 2, 29, 74, 6.5, 12, 55, 29),
    ("APC_SEO_06", "Seoul", "Asia-Pacific", 37.57, 126.98, 38, 13, 63, 4.1, 17, 46, 16),
]

FIELDS = [
    "timestamp", "station_id", "station_name", "region", "latitude", "longitude", "elevation_m",
    "temperature_c", "humidity_pct", "pressure_hpa", "rainfall_mm", "wind_speed_kmh", "co2_ppm",
    "solar_radiation_wm2", "soil_moisture_pct", "sea_surface_temp_c", "event_type", "is_extreme_event"
]


def clamp(v, low, high):
    return max(low, min(high, v))


def normal_observation(station, day_fraction):
    sid, city, region, lat, lon, elev, base_temp, base_hum, base_rain, base_wind, base_soil, base_sst = station
    seasonal = 5.5 * math.sin(2 * math.pi * day_fraction + (lat / 90.0))
    temperature = base_temp + seasonal + random.gauss(0, 2.0)
    humidity = clamp(base_hum + random.gauss(0, 7), 20, 98)
    pressure = clamp(1013 - (elev / 8500.0) * 75 + random.gauss(0, 5), 930, 1040)
    rainfall = max(0, random.gauss(base_rain, max(1.0, base_rain * 0.6)))
    wind = max(1, random.gauss(base_wind, 5))
    co2 = clamp(random.gauss(421, 10), 390, 460)
    solar = clamp(520 + 250 * math.sin(math.pi * day_fraction) + random.gauss(0, 90), 40, 1050)
    soil = clamp(base_soil + rainfall * 0.8 + random.gauss(0, 8), 8, 92)
    sst = clamp(base_sst + random.gauss(0, 1.6), -2, 33)
    return temperature, humidity, pressure, rainfall, wind, co2, solar, soil, sst


def inject_extreme(values, kind):
    t, h, p, r, w, c, s, soil, sst = values
    if kind == "Heatwave":
        t += random.uniform(9, 15); h -= random.uniform(8, 20); r *= random.uniform(0, .25); soil -= random.uniform(12, 28); s += random.uniform(80, 220); sst += random.uniform(1, 4)
    elif kind == "Heavy Rainfall":
        r = random.uniform(75, 220); h = random.uniform(86, 99); p -= random.uniform(12, 30); w += random.uniform(10, 35); soil += random.uniform(18, 35); s *= random.uniform(.25, .6)
    elif kind == "Wind Storm":
        w = random.uniform(70, 145); p -= random.uniform(22, 48); r += random.uniform(15, 85); h += random.uniform(5, 18); s *= random.uniform(.25, .65)
    elif kind == "Drought / Heat Stress":
        t += random.uniform(7, 13); h = random.uniform(15, 34); r = random.uniform(0, .8); soil = random.uniform(5, 20); s += random.uniform(110, 260); c += random.uniform(5, 25)
    return (
        clamp(t, -35, 52), clamp(h, 5, 100), clamp(p, 900, 1050), clamp(r, 0, 250),
        clamp(w, 0, 170), clamp(c, 370, 500), clamp(s, 0, 1200), clamp(soil, 2, 100), clamp(sst, -2, 36)
    )


def build(rows=2400):
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    start = datetime(2023, 1, 1, 0, 0, 0)
    event_types = ["Heatwave", "Heavy Rainfall", "Wind Storm", "Drought / Heat Stress"]
    with open(OUT, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        for i in range(rows):
            station = STATIONS[i % len(STATIONS)]
            ts = start + timedelta(hours=6 * i)
            day_fraction = (ts.timetuple().tm_yday - 1) / 365.0
            values = normal_observation(station, day_fraction)
            extreme = 1 if random.random() < 0.34 else 0
            event_type = "Normal Climate"
            if extreme:
                event_type = random.choice(event_types)
                values = inject_extreme(values, event_type)
            sid, city, region, lat, lon, elev = station[:6]
            t, h, p, r, w, c, s, soil, sst = values
            writer.writerow({
                "timestamp": ts.isoformat(timespec="minutes"),
                "station_id": sid,
                "station_name": city,
                "region": region,
                "latitude": round(lat, 4), "longitude": round(lon, 4), "elevation_m": elev,
                "temperature_c": round(t, 2), "humidity_pct": round(h, 2), "pressure_hpa": round(p, 2),
                "rainfall_mm": round(r, 2), "wind_speed_kmh": round(w, 2), "co2_ppm": round(c, 2),
                "solar_radiation_wm2": round(s, 2), "soil_moisture_pct": round(soil, 2),
                "sea_surface_temp_c": round(sst, 2), "event_type": event_type, "is_extreme_event": extreme,
            })
    print("Created", OUT, "with", rows, "rows")


if __name__ == "__main__":
    build()
