import os
import sqlite3
from datetime import datetime
from functools import wraps

from flask import Flask, flash, jsonify, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from cloud_core import ClimateCloudManager
from ml_engine import ClimateMLEngine

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "global_climate_system.db")

app = Flask(__name__)
app.secret_key = "global-climate-distributed-system-student-demo"
app.config["JSON_SORT_KEYS"] = False

cloud_manager = ClimateCloudManager()
ml_engine = ClimateMLEngine(BASE_DIR)


def db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = db_connection()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        mobile TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        address TEXT NOT NULL,
        created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS climate_observations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        login_user TEXT NOT NULL,
        station_id TEXT NOT NULL,
        station_name TEXT NOT NULL,
        region TEXT NOT NULL,
        cloud_id INTEGER NOT NULL,
        cloud_port INTEGER NOT NULL,
        temperature_c REAL NOT NULL,
        humidity_pct REAL NOT NULL,
        pressure_hpa REAL NOT NULL,
        rainfall_mm REAL NOT NULL,
        wind_speed_kmh REAL NOT NULL,
        co2_ppm REAL NOT NULL,
        solar_radiation_wm2 REAL NOT NULL,
        soil_moisture_pct REAL NOT NULL,
        sea_surface_temp_c REAL NOT NULL,
        prediction INTEGER NOT NULL,
        climate_status TEXT NOT NULL,
        event_type TEXT NOT NULL,
        created_at TEXT NOT NULL
    );
    """)
    conn.commit()
    conn.close()


init_db()


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "username" not in session:
            flash("Please login to access the global climate analytics console.", "warning")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


@app.context_processor
def inject_common():
    return {
        "current_user": session.get("username"),
        "server_status": cloud_manager.status(),
    }


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        mobile = request.form.get("mobile", "").strip()
        email = request.form.get("email", "").strip().lower()
        address = request.form.get("address", "").strip()

        if not all([username, password, mobile, email, address]):
            flash("All signup fields are required.", "danger")
            return render_template("signup.html")
        if len(password) < 6:
            flash("Password must contain at least 6 characters.", "danger")
            return render_template("signup.html")

        conn = db_connection()
        try:
            conn.execute(
                "INSERT INTO users(username,password_hash,mobile,email,address,created_at) VALUES(?,?,?,?,?,?)",
                (username, generate_password_hash(password), mobile, email, address,
                 datetime.now().isoformat(timespec="seconds")),
            )
            conn.commit()
        except sqlite3.IntegrityError:
            conn.close()
            flash("Username or email already exists.", "danger")
            return render_template("signup.html")
        conn.close()
        flash("Signup completed. Login to enter the climate analytics laboratory.", "success")
        return redirect(url_for("login"))
    return render_template("signup.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        conn = db_connection()
        user = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        conn.close()
        if user and check_password_hash(user["password_hash"], password):
            session["username"] = user["username"]
            flash("Login successful. Global climate analytics console is ready.", "success")
            return redirect(url_for("userpage"))
        flash("Username or password is incorrect.", "danger")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("home"))


@app.route("/about")
def about():
    return render_template("about.html", overview=ml_engine.dataset_overview())


@app.route("/userpage")
@login_required
def userpage():
    conn = db_connection()
    totals = conn.execute("""
        SELECT COUNT(*) total,
               SUM(CASE WHEN prediction=0 THEN 1 ELSE 0 END) normal,
               SUM(CASE WHEN prediction=1 THEN 1 ELSE 0 END) extreme,
               AVG(temperature_c) avg_temp
        FROM climate_observations WHERE login_user=?
    """, (session["username"],)).fetchone()
    conn.close()
    return render_template("userpage.html", totals=totals)


@app.route("/servers")
@login_required
def servers():
    return render_template("servers.html", logs=cloud_manager.recent_logs())


@app.route("/network")
@login_required
def network():
    return render_template("network.html")


@app.route("/machine-learning")
@login_required
def machine_learning():
    return render_template("machine_learning.html", metrics=ml_engine.metrics, best_model=ml_engine.model_name)


@app.route("/simulation")
@login_required
def simulation():
    return render_template("simulation.html")


@app.route("/activity")
@login_required
def activity():
    return render_template("activity.html")


@app.route("/api/start-servers", methods=["POST"])
@login_required
def api_start_servers():
    return jsonify(cloud_manager.start_all())


@app.route("/api/server-status")
@login_required
def api_server_status():
    return jsonify({"status": cloud_manager.status(), "logs": cloud_manager.recent_logs()})


@app.route("/api/train-ml", methods=["POST"])
@login_required
def api_train_ml():
    try:
        result = ml_engine.train_all()
        return jsonify({"ok": True, **result})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/api/simulate-observation", methods=["POST"])
@login_required
def api_simulate_observation():
    payload = request.get_json(silent=True) or {}
    node_number = int(payload.get("node_number", 1))
    cloud_id = int(payload.get("cloud_id", 1))

    statuses = {x["cloud_id"]: x["online"] for x in cloud_manager.status()}
    if not statuses.get(cloud_id):
        return jsonify({"ok": False, "error": "Regional Climate Cloud %d is offline. Start all climate clouds first." % cloud_id}), 409

    try:
        observation = ml_engine.generate_observation(node_number, cloud_id)
        cloud_reply = cloud_manager.send_observation(cloud_id, observation)
        if not cloud_reply.get("ok"):
            raise RuntimeError(cloud_reply.get("error", "Regional climate processing failed"))

        prediction = ml_engine.predict(observation)
        climate_status = "EXTREME EVENT" if prediction == 1 else "NORMAL CLIMATE"
        event_type = ml_engine.climate_event_name(observation, prediction)
        port = cloud_manager.PORTS[cloud_id]
        now = datetime.now().isoformat(timespec="seconds")

        conn = db_connection()
        conn.execute("""
            INSERT INTO climate_observations(
                login_user,station_id,station_name,region,cloud_id,cloud_port,
                temperature_c,humidity_pct,pressure_hpa,rainfall_mm,wind_speed_kmh,
                co2_ppm,solar_radiation_wm2,soil_moisture_pct,sea_surface_temp_c,
                prediction,climate_status,event_type,created_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            session["username"], observation["station_id"], observation["station_name"], observation["region"],
            cloud_id, port, observation["temperature_c"], observation["humidity_pct"], observation["pressure_hpa"],
            observation["rainfall_mm"], observation["wind_speed_kmh"], observation["co2_ppm"],
            observation["solar_radiation_wm2"], observation["soil_moisture_pct"], observation["sea_surface_temp_c"],
            prediction, climate_status, event_type, now
        ))
        conn.commit()
        conn.close()

        return jsonify({
            "ok": True,
            "visual_node": "Climate Node %d" % node_number,
            "station_id": observation["station_id"],
            "station_name": observation["station_name"],
            "region": observation["region"],
            "cloud_id": cloud_id,
            "cloud_port": port,
            "cloud_name": cloud_manager.REGIONS[cloud_id],
            "climate_status": climate_status,
            "event_type": event_type,
            "prediction": prediction,
            "model": ml_engine.model_name,
            "observation": observation,
            "processed_at": cloud_reply.get("processed_at"),
        })
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/api/activity-summary")
@login_required
def api_activity_summary():
    conn = db_connection()
    summary = conn.execute("""
        SELECT COUNT(*) total,
               SUM(CASE WHEN prediction=0 THEN 1 ELSE 0 END) normal,
               SUM(CASE WHEN prediction=1 THEN 1 ELSE 0 END) extreme,
               AVG(temperature_c) avg_temp,
               AVG(rainfall_mm) avg_rainfall
        FROM climate_observations WHERE login_user=?
    """, (session["username"],)).fetchone()
    rows = conn.execute("""
        SELECT id,station_id,station_name,region,cloud_id,cloud_port,temperature_c,
               humidity_pct,rainfall_mm,wind_speed_kmh,event_type,climate_status,created_at
        FROM climate_observations WHERE login_user=? ORDER BY id DESC LIMIT 100
    """, (session["username"],)).fetchall()
    region_rows = conn.execute("""
        SELECT region, COUNT(*) AS count FROM climate_observations
        WHERE login_user=? GROUP BY region ORDER BY region
    """, (session["username"],)).fetchall()
    conn.close()
    return jsonify({
        "total": int(summary["total"] or 0),
        "normal": int(summary["normal"] or 0),
        "extreme": int(summary["extreme"] or 0),
        "avg_temp": round(float(summary["avg_temp"] or 0), 2),
        "avg_rainfall": round(float(summary["avg_rainfall"] or 0), 2),
        "history": [dict(row) for row in rows],
        "regions": [dict(row) for row in region_rows],
    })


@app.route("/api/clear-history", methods=["POST"])
@login_required
def api_clear_history():
    conn = db_connection()
    conn.execute("DELETE FROM climate_observations WHERE login_user=?", (session["username"],))
    conn.commit()
    conn.close()
    return jsonify({"ok": True})


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8000, debug=False, threaded=True, use_reloader=False)
